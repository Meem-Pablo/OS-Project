/**
 * ============================================================================
 * scheduler.h - CPU Scheduler Module Header
 * ============================================================================
 * 
 * This header file defines the scheduler classes for CPU scheduling algorithms.
 * 
 * Part A Requirements:
 * - Priority Scheduling (Non-preemptive)
 * - Round Robin Scheduling (Preemptive)
 * - Dynamic scheduler selection based on process count
 * - Gantt Chart, Waiting Time, Turnaround Time, Average statistics
 * 
 * Scheduler Selection Rule:
 *   ≤ 5 ready processes → Priority Scheduling
 *   > 5 ready processes → Round Robin Scheduling
 * 
 * ============================================================================
 */

#ifndef SCHEDULER_H
#define SCHEDULER_H

#include "process.h"
#include <vector>
#include <queue>
#include <string>
#include <memory>
using namespace std;

/**
 * Scheduling Statistics Structure
 * 
 * Contains the results of a scheduling run, including:
 * - Average waiting and turnaround times
 * - Text-based Gantt chart
 * - List of completed processes with their statistics
 */
struct SchedulingStats {
    double avgWaitingTime;              ///< Average waiting time across all processes
    double avgTurnaroundTime;          ///< Average turnaround time across all processes
    string ganttChart;                 ///< Text-based Gantt chart visualization
    vector<Process> completedProcesses; ///< List of all completed processes with statistics
};

/**
 * Base Scheduler Abstract Class
 * 
 * Defines the interface that all scheduling algorithms must implement.
 * Uses polymorphism to allow dynamic scheduler selection.
 */
class Scheduler {
public:
    virtual ~Scheduler() = default;
    
    /**
     * Schedule Processes
     * 
     * Executes the scheduling algorithm on the given process list.
     * Modifies processes in-place to update their statistics.
     * 
     * @param processes Vector of processes to schedule
     * @return SchedulingStats containing results and statistics
     */
    virtual SchedulingStats schedule(vector<Process>& processes) = 0;
    
    /**
     * Get Scheduler Name
     * 
     * @return Human-readable name of the scheduler
     */
    virtual string getName() const = 0;
};

/**
 * Priority Scheduling (Non-preemptive)
 * 
 * Algorithm: Selects the process with the highest priority number.
 * Once selected, a process runs to completion without preemption.
 * 
 * Priority Rule: Higher numeric value = Higher priority
 * Example: Priority 10 > Priority 5 > Priority 1
 * 
 * Characteristics:
 * - Non-preemptive: No interruption once execution starts
 * - Starvation possible: Low priority processes may wait indefinitely
 * - Efficient for small workloads
 */
class PriorityScheduler : public Scheduler {
public:
    SchedulingStats schedule(vector<Process>& processes) override;
    string getName() const override { return "Priority Scheduling (Non-preemptive)"; }
};

/**
 * Round Robin Scheduling (Preemptive)
 * 
 * Algorithm: Processes are scheduled in a circular fashion with a fixed
 * time quantum. When a process's quantum expires, it is preempted and
 * added back to the ready queue.
 * 
 * Time Quantum: 2 time units (configurable)
 * 
 * Characteristics:
 * - Preemptive: Processes can be interrupted
 * - Fair: All processes get equal CPU time
 * - Prevents starvation
 * - Good for time-sharing systems
 */
class RoundRobinScheduler : public Scheduler {
private:
    int timeQuantum;  ///< Time quantum in time units (default: 2)
    
public:
    /**
     * Constructor
     * 
     * @param quantum Time quantum for Round Robin (default: 2)
     */
    RoundRobinScheduler(int quantum = 2) : timeQuantum(quantum) {}
    
    SchedulingStats schedule(vector<Process>& processes) override;
    string getName() const override { return "Round Robin Scheduling (Preemptive)"; }
};

/**
 * Scheduler Factory
 * 
 * Implements the dynamic scheduler selection rule:
 * - ≤ 5 ready processes: Use Priority Scheduling
 * - > 5 ready processes: Use Round Robin Scheduling
 * 
 * This factory pattern allows the system to automatically select
 * the most appropriate scheduler based on current workload.
 */
class SchedulerFactory {
public:
    /**
     * Create Appropriate Scheduler
     * 
     * Selects and creates a scheduler instance based on the number
     * of ready processes.
     * 
     * @param numProcesses Number of ready processes
     * @return Unique pointer to appropriate scheduler instance
     */
    static unique_ptr<Scheduler> createScheduler(int numProcesses);
};

#endif // SCHEDULER_H
