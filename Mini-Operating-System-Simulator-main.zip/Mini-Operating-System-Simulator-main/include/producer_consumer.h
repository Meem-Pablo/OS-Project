/**
 * ============================================================================
 * producer_consumer.h - Producer-Consumer Module Header
 * ============================================================================
 * 
 * This header file defines the Producer-Consumer pattern implementation for
 * concurrent process generation and consumption.
 * 
 * Part B Requirements:
 * - At least 2 producer threads
 * - At least 1 consumer thread (CPU)
 * - Bounded buffer (ready queue)
 * - Semaphores for empty/full buffer synchronization
 * - Mutex for mutual exclusion
 * - NO BUSY WAITING (all waits are blocking)
 * 
 * ============================================================================
 */

#ifndef PRODUCER_CONSUMER_H
#define PRODUCER_CONSUMER_H

#include "process.h"
#include <queue>
#include <mutex>
#include <semaphore.h>  // POSIX semaphores
#include <thread>
#include <atomic>
#include <vector>
using namespace std;

/**
 * Bounded Buffer Class
 * 
 * Implements a thread-safe bounded buffer using semaphores and mutexes.
 * This buffer acts as the shared memory between producer and consumer threads.
 * 
 * Synchronization Strategy:
 * - Semaphores: Control buffer capacity (empty/full slots)
 * - Mutex: Protect critical sections (actual buffer access)
 * - No Busy Waiting: All waits are blocking (threads sleep when waiting)
 */
class BoundedBuffer {
private:
    queue<Process> buffer;      ///< Internal buffer storing processes
    size_t maxSize;             ///< Maximum capacity of the buffer
    
    // Semaphores for synchronization (NO BUSY WAITING)
    sem_t emptySlots;           ///< Counts available empty slots (init = maxSize)
    sem_t fullSlots;            ///< Counts filled slots (init = 0)
    
    mutex mtx;                  ///< Mutex for protecting buffer access (critical section)
    
public:
    /**
     * Constructor
     * 
     * Initializes the bounded buffer with specified size and sets up
     * semaphores for synchronization.
     * 
     * @param size Maximum number of processes the buffer can hold
     */
    BoundedBuffer(size_t size);
    
    /**
     * Destructor
     * 
     * Cleans up semaphore resources.
     */
    ~BoundedBuffer();
    
    /**
     * Produce (Add Process to Buffer)
     * 
     * Producer operation: Adds a process to the buffer.
     * 
     * Synchronization Flow:
     * 1. Wait for empty slot (sem_wait blocks if buffer full - NO BUSY WAITING)
     * 2. Acquire mutex (enter critical section)
     * 3. Add process to buffer
     * 4. Release mutex (exit critical section)
     * 5. Signal that a slot is now full (sem_post)
     * 
     * @param process Process to add to buffer
     * @return true if successful
     */
    bool produce(const Process& process);
    
    /**
     * Consume (Remove Process from Buffer)
     * 
     * Consumer operation: Removes a process from the buffer.
     * 
     * Synchronization Flow:
     * 1. Wait for full slot (sem_wait blocks if buffer empty - NO BUSY WAITING)
     * 2. Acquire mutex (enter critical section)
     * 3. Remove process from buffer
     * 4. Release mutex (exit critical section)
     * 5. Signal that a slot is now empty (sem_post)
     * 
     * @param process Reference to store the consumed process
     * @return true if successful, false if buffer was empty
     */
    bool consume(Process& process);
    
    /**
     * Get Current Buffer Size
     * 
     * @return Number of processes currently in buffer
     */
    size_t size() const;
    
    /**
     * Check if Buffer is Empty
     * 
     * @return true if buffer is empty
     */
    bool isEmpty() const;
    
    /**
     * Check if Buffer is Full
     * 
     * @return true if buffer is at maximum capacity
     */
    bool isFull() const;
    
    /**
     * Get All Processes in Buffer
     * 
     * Returns a copy of all processes currently in the buffer.
     * Used for display purposes.
     * 
     * @return Vector containing all processes in buffer
     */
    vector<Process> getAllProcesses() const;
};

/**
 * Producer-Consumer Manager Class
 * 
 * Manages producer and consumer threads for concurrent process generation.
 * 
 * Thread Configuration:
 * - 2+ Producer Threads: Generate processes dynamically
 * - 1+ Consumer Thread: Fetches processes and adds to ready queue
 */
class ProducerConsumerManager {
private:
    BoundedBuffer* buffer;              ///< Shared bounded buffer
    vector<thread> producerThreads;      ///< Producer thread handles
    thread consumerThread;              ///< Consumer thread handle
    
    atomic<bool> running;               ///< Flag to control thread execution
    atomic<int> processIdCounter;       ///< Thread-safe process ID counter
    
    /**
     * Producer Thread Function
     * 
     * Generates processes dynamically with random attributes and adds
     * them to the bounded buffer.
     * 
     * Process Generation:
     * - Random Process ID (auto-incremented)
     * - Random Arrival Time (0-5)
     * - Random Burst Time (1-10)
     * - Random Priority (1-10)
     * - Random Resource Requirements (0-3 per resource type)
     * 
     * @param producerId Unique identifier for this producer thread
     */
    void producerFunction(int producerId);
    
    /**
     * Consumer Thread Function
     * 
     * Consumes processes from the bounded buffer and adds them to
     * the ready queue for scheduling.
     * 
     * @param readyQueue Reference to the ready queue (protected by queueMutex)
     * @param queueMutex Mutex protecting the ready queue
     */
    void consumerFunction(vector<Process>& readyQueue, 
                         mutex& queueMutex);
    
public:
    /**
     * Constructor
     * 
     * @param buf Pointer to the bounded buffer
     * @param numProducers Number of producer threads (default: 2)
     */
    ProducerConsumerManager(BoundedBuffer* buf, int numProducers = 2);
    
    /**
     * Destructor
     * 
     * Ensures threads are stopped and joined properly.
     */
    ~ProducerConsumerManager();
    
    /**
     * Start Producer-Consumer Threads
     * 
     * Creates and starts all producer and consumer threads.
     * 
     * @param readyQueue Reference to ready queue for consumer
     * @param queueMutex Mutex protecting the ready queue
     */
    void start(vector<Process>& readyQueue, mutex& queueMutex);
    
    /**
     * Stop Producer-Consumer Threads
     * 
     * Signals threads to stop and waits for them to finish.
     * Ensures clean shutdown.
     */
    void stop();
    
    /**
     * Check if Manager is Running
     * 
     * @return true if threads are currently running
     */
    bool isRunning() const { return running.load(); }
    
    /**
     * Get Next Process ID
     * 
     * Thread-safe method to get the next available process ID.
     * Uses atomic operations to prevent race conditions.
     * 
     * @return Next process ID
     */
    int getNextProcessId() { return processIdCounter.fetch_add(1); }
};

#endif // PRODUCER_CONSUMER_H
