#ifndef BANKER_H
#define BANKER_H

#include "process.h"
#include <vector>
#include <string>
using namespace std;

/**
 * Banker's Algorithm for Deadlock Prevention
 * Manages resource allocation and ensures system safety
 */
class BankersAlgorithm {
private:
    int numResourceTypes;
    vector<int> available;  // Available resources
    vector<vector<int>> max;  // Maximum demand matrix
    vector<vector<int>> allocation;  // Currently allocated resources
    vector<vector<int>> need;  // Need matrix (max - allocation)
    
    /**
     * Safety algorithm to check if system is in safe state
     * Returns safe sequence if exists, empty vector otherwise
     */
    vector<int> safetyAlgorithm();
    
public:
    BankersAlgorithm(int numResources, const vector<int>& availableResources);
    
    /**
     * Request resources for a process
     * Returns true if request can be granted safely, false otherwise
     */
    bool requestResources(int processId, const vector<int>& request);
    
    /**
     * Release resources when process completes
     */
    void releaseResources(int processId);
    
    /**
     * Check if process can be allocated resources safely
     */
    bool canAllocate(int processId, const Process& process);
    
    /**
     * Get safe sequence if system is safe
     */
    vector<int> getSafeSequence();
    
    /**
     * Display current system state
     */
    void displayState() const;
    
    /**
     * Initialize process in system
     */
    void addProcess(int processId, const vector<int>& maxResources);
    
    /**
     * Get list of blocked processes (processes that cannot be allocated)
     */
    vector<int> getBlockedProcesses(const vector<Process>& processes);
};

#endif // BANKER_H
