/**
 * ============================================================================
 * process.h - Process Data Structure Definition
 * ============================================================================
 * 
 * This header file defines the Process structure which represents a process
 * in the operating system simulator. Each process contains all necessary
 * information for scheduling algorithms and resource management.
 * 
 * Part A Requirements:
 * - Process ID
 * - Arrival Time
 * - CPU Burst Time
 * - Priority
 * - Resource Requirement Vector (R1, R2, ...)
 * 
 * ============================================================================
 */

#ifndef PROCESS_H
#define PROCESS_H

#include <vector>
#include <string>
using namespace std;

/**
 * Process Structure
 * 
 * Represents a single process in the OS simulator with all attributes
 * required for scheduling and resource management.
 */
struct Process {
    // ========================================================================
    // Basic Process Attributes (Part A Requirements)
    // ========================================================================
    
    int processId;              ///< Unique identifier for the process (P1, P2, ...)
    int arrivalTime;            ///< Time when process arrives in the system
    int burstTime;              ///< Total CPU time required for execution
    int priority;               ///< Priority level (higher number = higher priority)
    
    /**
     * Resource Requirement Vector (MAX Matrix Entry)
     * 
     * Specifies the MAXIMUM resources this process will EVER need during its lifetime.
     * This becomes the MAX matrix entry in Banker's Algorithm.
     * 
     * Example: [2, 3] means:
     *   - Maximum 2 units of R1 the process will ever need
     *   - Maximum 3 units of R2 the process will ever need
     * 
     * Important: This is the MAXIMUM, not the current request.
     * The process can request resources up to this amount, but not more.
     * Used by Banker's Algorithm for deadlock prevention.
     */
    vector<int> resourceRequirement;
    
    // ========================================================================
    // Scheduling Statistics (Calculated during execution)
    // ========================================================================
    
    int waitingTime;            ///< Time process spends waiting in ready queue
    int turnaroundTime;         ///< Total time from arrival to completion
    int completionTime;         ///< Time when process finishes execution
    int remainingTime;          ///< Remaining burst time (used for Round Robin)
    
    // ========================================================================
    // Resource Allocation Tracking (For Banker's Algorithm)
    // ========================================================================
    
    vector<int> allocatedResources;  ///< Currently allocated resources
    vector<int> maxResources;        ///< Maximum resource requirements
    
    // ========================================================================
    // Status Flags
    // ========================================================================
    
    bool isCompleted;           ///< True if process has finished execution
    bool isBlocked;             ///< True if process is blocked (unsafe resource allocation)
    
    // ========================================================================
    // Constructor and Methods
    // ========================================================================
    
    /**
     * Constructor
     * 
     * @param id        Process ID
     * @param arrival   Arrival time
     * @param burst     Burst time (CPU time required)
     * @param prio      Priority (higher number = higher priority)
     * @param resources Resource requirement vector (default: empty)
     */
    Process(int id, int arrival, int burst, int prio, 
            const vector<int>& resources = vector<int>());
    
    /**
     * Reset Process State
     * 
     * Resets all scheduling statistics to initial values.
     * Used when re-running schedulers on the same process set.
     */
    void reset();
    
    /**
     * Convert Process to String
     * 
     * @return String representation: "P1 [AT:0 BT:5 P:3]"
     */
    string toString() const;
};

#endif // PROCESS_H
