# Mini Operating System Simulator
## Complex Computing Problem (CCP) - Project Report

**Author:** [Your Name]  
**Date:** [Date]  
**Course:** Operating Systems  
**Project:** Mini OS Simulator - Integrated Process Management System

---

## Table of Contents

1. [Introduction](#1-introduction)
2. [System Architecture](#2-system-architecture)
3. [Module-wise Explanation](#3-module-wise-explanation)
4. [Scheduling Decisions](#4-scheduling-decisions)
5. [Semaphore Usage Explanation](#5-semaphore-usage-explanation)
6. [Deadlock Prevention Logic](#6-deadlock-prevention-logic)
7. [Integration and System Flow](#7-integration-and-system-flow)
8. [Limitations of Current Simulator](#8-limitations-of-current-simulator)
9. [Conclusion](#9-conclusion)

---

## 1. Introduction

This report documents the design and implementation of a Mini Operating System Simulator that integrates three core OS concepts: Process Scheduling, Producer-Consumer synchronization, and Deadlock Prevention using Banker's Algorithm. The simulator demonstrates how an operating system manages processes, allocates resources, and prevents unsafe states in a concurrent environment.

### Objectives

- Simulate CPU scheduling using Priority and Round Robin algorithms
- Implement concurrent process generation and consumption using semaphores
- Prevent deadlocks using Banker's Algorithm for resource allocation
- Provide an integrated system demonstrating real OS behavior

---

## 2. System Architecture

The simulator is built as a modular system consisting of four main components:

```
┌─────────────────────────────────────────────────────────┐
│              Mini OS Simulator                          │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌──────────────┐  ┌──────────────┐  ┌─────────────┐│
│  │   Process    │  │  Scheduler   │  │  Producer-   ││
│  │   Module     │  │   Module     │  │  Consumer   ││
│  │              │  │              │  │   Module    ││
│  └──────────────┘  └──────────────┘  └─────────────┘│
│                                                         │
│  ┌──────────────────────────────────────────────────┐ │
│  │      Banker's Algorithm (Deadlock Prevention)    │ │
│  └──────────────────────────────────────────────────┘ │
│                                                         │
│  ┌──────────────────────────────────────────────────┐ │
│  │           Main Menu & Integration Layer            │ │
│  └──────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────┘
```

### Component Overview

1. **Process Module**: Defines process structure with all required attributes
2. **Scheduler Module**: Implements Priority and Round Robin scheduling algorithms
3. **Producer-Consumer Module**: Handles concurrent process generation and consumption
4. **Banker's Algorithm Module**: Manages resource allocation and deadlock prevention

---

## 3. Module-wise Explanation

### 3.1 Process Module

**File:** `process.h`, `process.cpp`

The Process module defines the fundamental data structure representing a process in the system.

#### Key Attributes:

- **Process ID**: Unique identifier for each process
- **Arrival Time**: Time when process enters the system
- **Burst Time**: CPU time required for execution
- **Priority**: Priority level (higher number = higher priority)
- **Resource Requirement Vector**: Array specifying required resources (R1, R2, ...)
- **Scheduling Statistics**: Waiting time, turnaround time, completion time
- **Status Flags**: `isCompleted`, `isBlocked` for state tracking

#### Implementation Details:

```cpp
struct Process {
    int processId;
    int arrivalTime;
    int burstTime;
    int priority;
    vector<int> resourceRequirement;
    int waitingTime;
    int turnaroundTime;
    int completionTime;
    int remainingTime;  // For Round Robin
    bool isCompleted;
    bool isBlocked;
};
```

The `reset()` method initializes scheduling statistics, and `toString()` provides formatted output for display purposes.

---

### 3.2 Scheduler Module

**File:** `scheduler.h`, `scheduler.cpp`

The Scheduler module implements two classical CPU scheduling algorithms with dynamic selection based on system load.

#### 3.2.1 Priority Scheduling (Non-preemptive)

**Algorithm:** Priority Scheduling selects the process with the highest priority number from the ready queue. Once selected, a process runs to completion without preemption.

**Key Features:**
- Processes sorted by priority (higher number = higher priority)
- Non-preemptive: Process runs until completion
- Handles arrival times correctly
- Calculates waiting time, turnaround time, and completion time

**Implementation Flow:**
1. Sort processes by arrival time
2. At each time unit, add arrived processes to ready queue
3. Sort ready queue by priority (descending)
4. Execute highest priority process completely
5. Update statistics and generate Gantt chart

**Time Complexity:** O(n² log n) due to sorting operations

#### 3.2.2 Round Robin Scheduling (Preemptive)

**Algorithm:** Round Robin uses a time quantum (2 units) to preemptively schedule processes in a circular fashion.

**Key Features:**
- Time quantum = 2 units (configurable)
- Preemptive: Process interrupted after quantum expires
- Fair scheduling: All processes get equal CPU time
- Processes return to queue if not completed

**Implementation Flow:**
1. Sort processes by arrival time
2. Add arrived processes to ready queue
3. Execute current process for time quantum (or until completion)
4. If process not completed, add back to queue
5. Update waiting time for processes in queue
6. Continue until all processes complete

**Time Complexity:** O(n × total_execution_time / quantum)

#### 3.2.3 Scheduler Factory

**Dynamic Selection Rule:**
- **≤ 5 ready processes**: Priority Scheduling
- **> 5 ready processes**: Round Robin Scheduling

This rule ensures optimal performance: Priority for small workloads, Round Robin for fair distribution in larger workloads.

**Output Statistics:**
- Gantt Chart (text-based visualization)
- Individual process waiting times
- Individual process turnaround times
- Average waiting time
- Average turnaround time

---

### 3.3 Producer-Consumer Module

**File:** `producer_consumer.h`, `producer_consumer.cpp`

This module implements the classic Producer-Consumer pattern with proper synchronization to simulate concurrent process generation.

#### 3.3.1 Bounded Buffer

**Purpose:** Acts as a shared buffer between producers and consumers with fixed capacity (size = 10).

**Synchronization Mechanisms:**

1. **Semaphores:**
   - `emptySlots`: Counts available empty slots (initialized to buffer size)
   - `fullSlots`: Counts filled slots (initialized to 0)

2. **Mutex:**
   - `mtx`: Protects critical sections (buffer access)

**Producer Operation (`produce`):**
```cpp
sem_wait(&emptySlots);      // Wait for empty slot (blocks if full)
lock_guard<mutex> lock(mtx); // Enter critical section
buffer.push(process);        // Add process to buffer
sem_post(&fullSlots);        // Signal one more full slot
```

**Consumer Operation (`consume`):**
```cpp
sem_wait(&fullSlots);        // Wait for full slot (blocks if empty)
lock_guard<mutex> lock(mtx); // Enter critical section
process = buffer.front();     // Remove process from buffer
buffer.pop();
sem_post(&emptySlots);       // Signal one more empty slot
```

**No Busy Waiting:** All waits use blocking semaphores (`sem_wait`), ensuring threads sleep when waiting rather than consuming CPU cycles.

#### 3.3.2 Producer-Consumer Manager

**Thread Configuration:**
- **2 Producer Threads**: Generate processes dynamically with random attributes
- **1 Consumer Thread**: Fetches processes from buffer and adds to ready queue

**Process Generation:**
- Random Process ID (auto-incremented)
- Random Arrival Time (0-5)
- Random Burst Time (1-10)
- Random Priority (1-10)
- Random Resource Requirements (0-3 for each resource type)

**Thread Lifecycle:**
1. Start: Creates producer and consumer threads
2. Running: Threads operate concurrently
3. Stop: Gracefully terminates threads and waits for completion

---

### 3.4 Banker's Algorithm Module

**File:** `banker.h`, `banker.cpp`

This module implements a simplified Banker's Algorithm to prevent deadlocks by ensuring the system never enters an unsafe state.

#### Data Structures:

1. **Available Vector**: Current available resources [R1, R2, ...]
2. **Max Matrix**: Maximum resource demand for each process
3. **Allocation Matrix**: Currently allocated resources per process
4. **Need Matrix**: Remaining resource need (Need = Max - Allocation)

#### Key Operations:

**1. Add Process:**
- Registers process with maximum resource requirements
- Initializes allocation to zero
- Sets need equal to max

**2. Safety Algorithm:**
- Checks if system is in safe state
- Finds a safe sequence if one exists
- Returns empty vector if unsafe

**Algorithm Steps:**
```
1. Initialize work = available, finish[i] = false
2. Find process i where:
   - finish[i] == false
   - need[i] <= work
3. If found:
   - work = work + allocation[i]
   - finish[i] = true
   - Add i to safe sequence
   - Repeat step 2
4. If all processes finished: return safe sequence
5. Else: return empty (unsafe state)
```

**3. Resource Request:**
- Validates request (doesn't exceed need or available)
- Temporarily allocates resources
- Runs safety algorithm
- If safe: commit allocation
- If unsafe: rollback and deny request

**4. Resource Release:**
- Called when process completes
- Releases all allocated resources
- Updates available vector

---

## 4. Scheduling Decisions

### 4.1 Scheduler Selection Logic

The system uses a **dynamic scheduler selection** mechanism based on the number of ready processes:

| Condition | Scheduler Used | Rationale |
|-----------|----------------|-----------|
| ≤ 5 processes | Priority Scheduling | Efficient for small workloads, minimizes context switches |
| > 5 processes | Round Robin | Ensures fairness, prevents starvation, better for larger workloads |

**Implementation:**
```cpp
unique_ptr<Scheduler> SchedulerFactory::createScheduler(int numProcesses) {
    if (numProcesses <= 5) {
        return unique_ptr<Scheduler>(new PriorityScheduler());
    } else {
        return unique_ptr<Scheduler>(new RoundRobinScheduler());
    }
}
```

### 4.2 Priority Scheduling Decisions

**Priority Assignment:**
- Higher numeric value = Higher priority
- Example: Priority 10 > Priority 5 > Priority 1

**Tie-Breaking:**
- If multiple processes have same priority, first-come-first-served (FCFS) order

**Non-Preemptive Nature:**
- Once a process starts execution, it runs to completion
- New high-priority arrivals must wait for current process to finish
- Reduces context switching overhead

### 4.3 Round Robin Decisions

**Time Quantum Selection:**
- Fixed quantum = 2 time units
- Balance between responsiveness and overhead
- Small enough for interactive feel, large enough to minimize overhead

**Preemption Logic:**
- Process preempted after quantum expires
- Preempted process returns to end of ready queue
- Ensures fair CPU distribution

**Waiting Time Calculation:**
- Accumulated while process waits in ready queue
- Updated for all queued processes during each execution cycle

---

## 5. Semaphore Usage Explanation

### 5.1 Semaphore Types

The system uses **counting semaphores** to manage buffer synchronization:

1. **`emptySlots` Semaphore:**
   - Initial value: Buffer size (10)
   - Decremented: When producer adds item (`sem_wait`)
   - Incremented: When consumer removes item (`sem_post`)
   - Purpose: Tracks available buffer space

2. **`fullSlots` Semaphore:**
   - Initial value: 0
   - Decremented: When consumer removes item (`sem_wait`)
   - Incremented: When producer adds item (`sem_post`)
   - Purpose: Tracks filled buffer slots

### 5.2 Synchronization Flow

#### Producer Thread Flow:
```
1. Generate process
2. sem_wait(&emptySlots)  → Wait if buffer full (BLOCKS)
3. lock_guard<mutex>       → Enter critical section
4. buffer.push(process)    → Add to buffer
5. sem_post(&fullSlots)    → Signal consumer
```

#### Consumer Thread Flow:
```
1. sem_wait(&fullSlots)    → Wait if buffer empty (BLOCKS)
2. lock_guard<mutex>       → Enter critical section
3. process = buffer.front()→ Remove from buffer
4. buffer.pop()
5. sem_post(&emptySlots)    → Signal producer
```

### 5.3 Why Semaphores?

**Advantages:**
- **No Busy Waiting**: Threads block when waiting, saving CPU cycles
- **Efficient**: Kernel-level blocking is more efficient than polling
- **Scalable**: Works with multiple producers/consumers
- **Prevents Race Conditions**: Ensures proper synchronization

**Comparison with Alternatives:**
- **Busy Waiting**: Wastes CPU, not used (requirement)
- **Condition Variables**: More complex, semaphores sufficient here
- **Mutex Only**: Cannot track buffer state (empty/full)

### 5.4 Mutex Usage

**Purpose:** Protects critical sections where buffer is accessed

**Critical Sections:**
- Buffer push/pop operations
- Buffer size checks
- Buffer state queries

**Why Both Semaphores and Mutex?**
- **Semaphores**: Control buffer capacity (empty/full)
- **Mutex**: Ensure atomic buffer operations (prevent race conditions)

**Example Race Condition Prevented:**
Without mutex, two producers could simultaneously:
1. Check buffer size
2. Both see space available
3. Both add items → Buffer overflow!

Mutex ensures only one thread accesses buffer at a time.

---

## 6. Deadlock Prevention Logic

### 6.1 Banker's Algorithm Overview

The Banker's Algorithm prevents deadlocks by ensuring the system **never enters an unsafe state**. An unsafe state is one where deadlock is possible, even if it hasn't occurred yet.

### 6.2 Safety Check Before Execution

**Critical Rule:** Before a process executes, the system checks if granting its requested resources would keep the system in a safe state.

**Process Flow:**
```
1. Process requests resources
2. Check: Can resources be allocated? (available >= request)
3. Check: Would allocation keep system safe? (Safety Algorithm)
4. If safe: Allocate resources, allow execution
5. If unsafe: Block process, deny allocation
```

### 6.3 Safety Algorithm Implementation

**Purpose:** Determines if system is in safe state and finds safe execution sequence.

**Algorithm:**
```
Safety Algorithm:
1. Initialize:
   - work = available (copy of available resources)
   - finish[i] = false for all processes
   - safeSequence = []

2. Find process i where:
   - finish[i] == false
   - need[i] <= work (process can complete with current resources)

3. If such process found:
   - work = work + allocation[i] (simulate completion)
   - finish[i] = true
   - safeSequence.append(i)
   - Go to step 2

4. If all processes finished:
   - Return safeSequence (SAFE STATE)

5. If no process found but unfinished processes remain:
   - Return [] (UNSAFE STATE)
```

### 6.4 Resource Request Handling

**Request Validation:**
1. Check if request ≤ need (process doesn't request more than declared)
2. Check if request ≤ available (resources exist)
3. Temporarily allocate resources
4. Run safety algorithm
5. If safe: Commit allocation
6. If unsafe: Rollback allocation, block process

**Example Scenario:**
```
System State:
- Available: [3, 3]
- Process P1 needs: [2, 2]
- Process P2 needs: [1, 1]

Request: P1 requests [2, 2]
- Available becomes: [1, 1]
- Check safety: Can P2 complete? Yes (need [1,1] <= available [1,1])
- Safe sequence: P2 → P1
- Allocation granted ✓

Request: P1 requests [3, 3] (if available was [3,3])
- Available becomes: [0, 0]
- Check safety: Can P2 complete? No (need [1,1] > available [0,0])
- No safe sequence exists
- Allocation denied, P1 blocked ✗
```

### 6.5 Process Blocking

**When Blocked:**
- Resource request would lead to unsafe state
- Resources not currently available
- Request exceeds declared maximum need

**Blocked Process Handling:**
- Process marked with `isBlocked = true`
- Not added to ready queue for scheduling
- Remains blocked until resources become available
- Displayed in "Blocked Processes" list

### 6.6 Resource Release

**When Process Completes:**
- All allocated resources released
- Available vector updated
- Process removed from system
- May unblock other processes

**Release Logic:**
```cpp
void releaseResources(int processId) {
    for each resource type:
        available[i] += allocation[processId][i]
        allocation[processId][i] = 0
        need[processId][i] = max[processId][i]
}
```

---

## 7. Integration and System Flow

### 7.1 Complete System Flow

```
┌─────────────────────────────────────────────────────────┐
│                    START SIMULATION                     │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
        ┌────────────────────────┐
        │  Producer Threads (×2) │───┐
        │  Generate Processes    │   │
        └────────────┬───────────┘   │
                     │               │
                     ▼               │
        ┌────────────────────────┐  │
        │   Bounded Buffer       │  │
        │   (Semaphore Protected) │  │
        └────────────┬───────────┘  │
                     │               │
                     │               │
        ┌────────────▼───────────┐  │
        │  Consumer Thread (×1)   │  │
        │  Fetch from Buffer      │  │
        └────────────┬───────────┘  │
                     │               │
                     ▼               │
        ┌────────────────────────┐  │
        │     Ready Queue        │  │
        └────────────┬───────────┘  │
                     │               │
                     ▼               │
        ┌────────────────────────┐  │
        │  Banker's Algorithm    │  │
        │  Safety Check          │  │
        └────────────┬───────────┘  │
                     │               │
         ┌───────────┴───────────┐ │
         │   Safe?                │ │
         └───────────┬───────────┘ │
                     │               │
        ┌────────────┴───────────┐  │
        │                         │  │
        ▼                         ▼  │
   [ALLOWED]                [BLOCKED]│
        │                         │  │
        │                         │  │
        ▼                         │  │
┌───────────────┐                 │  │
│   Scheduler   │                 │  │
│   Selection   │                 │  │
│   (≤5: Priority│                │  │
│   >5: Round   │                 │  │
│    Robin)     │                 │  │
└───────┬───────┘                 │  │
        │                         │  │
        ▼                         │  │
┌───────────────┐                 │  │
│   Execute     │                 │  │
│   Processes   │                 │  │
└───────┬───────┘                 │  │
        │                         │  │
        ▼                         │  │
┌───────────────┐                 │  │
│   Release     │                 │  │
│   Resources   │                 │  │
└───────────────┘                 │  │
                                  │  │
                                  └──┘
                            (Loop continues)
```

### 7.2 Menu System Integration

**Menu Options:**

1. **Start Simulation:**
   - Starts producer-consumer threads
   - Processes generated and consumed concurrently
   - User presses Enter to stop and run scheduler

2. **Add Process Manually:**
   - User inputs process attributes
   - System checks resource allocation safety
   - Process added or blocked based on safety

3. **Display System State:**
   - Shows all processes and status
   - Displays buffer state
   - Shows Banker's Algorithm matrices
   - Lists safe sequence and blocked processes

4. **Exit:**
   - Clean shutdown of all threads
   - Resource cleanup

---

## 8. Limitations of Current Simulator

### 8.1 Simplified Banker's Algorithm

**Limitation:** The implementation uses a simplified version of Banker's Algorithm.

**Details:**
- Fixed number of resource types (currently 2: R1, R2)
- Simplified safety check for demonstration purposes
- Does not handle dynamic resource requests during execution

**Impact:** May not accurately represent complex real-world scenarios with many resource types.

### 8.2 Fixed Time Quantum

**Limitation:** Round Robin time quantum is fixed at 2 units.

**Details:**
- Not adaptive to process characteristics
- Cannot adjust based on system load
- May not be optimal for all workloads

**Impact:** May lead to suboptimal scheduling for certain process mixes.

### 8.3 Fixed Buffer Size

**Limitation:** Bounded buffer size is fixed at 10 processes.

**Details:**
- Not configurable at runtime
- May cause blocking if many processes generated quickly
- Does not adapt to system load

**Impact:** May limit throughput in high-load scenarios.

### 8.4 Process Generation

**Limitation:** Random process generation may not reflect real-world patterns.

**Details:**
- Random attributes (arrival, burst, priority)
- No correlation between process characteristics
- No bursty arrival patterns

**Impact:** May not accurately simulate real OS workloads.

### 8.5 No Process Migration

**Limitation:** Processes cannot move between queues or change priority.

**Details:**
- No priority aging mechanism
- No queue promotion/demotion
- Processes remain in same state until completion

**Impact:** Cannot handle dynamic priority adjustments or load balancing.

### 8.6 Single CPU Assumption

**Limitation:** Simulator assumes single CPU core.

**Details:**
- No multi-core scheduling
- No parallel execution
- No CPU affinity considerations

**Impact:** Does not represent modern multi-core systems.

### 8.7 No I/O Operations

**Limitation:** Processes are CPU-bound only.

**Details:**
- No I/O waiting states
- No device scheduling
- Processes only in Ready/Running/Completed states

**Impact:** Does not represent I/O-intensive workloads.

### 8.8 Limited Statistics

**Limitation:** Basic scheduling statistics only.

**Details:**
- No throughput metrics
- No CPU utilization tracking
- No response time for interactive processes
- No context switch counting

**Impact:** Limited performance analysis capabilities.

### 8.9 No Real-time Scheduling

**Limitation:** No support for real-time scheduling algorithms.

**Details:**
- No deadline-based scheduling
- No rate monotonic scheduling
- No earliest deadline first (EDF)

**Impact:** Cannot simulate real-time systems.

### 8.10 Synchronization Overhead

**Limitation:** Semaphore and mutex overhead not measured.

**Details:**
- No performance metrics for synchronization
- Overhead not accounted for in timing
- May not reflect actual OS overhead

**Impact:** Timing may not be accurate for performance analysis.

---

## 9. Conclusion

This Mini OS Simulator successfully integrates three fundamental operating system concepts: CPU scheduling, process synchronization, and deadlock prevention. The modular design allows for easy extension and modification, making it suitable as a foundation for more advanced projects.

### Key Achievements:

1. ✅ **Dynamic Scheduler Selection**: Automatically chooses optimal scheduler based on workload
2. ✅ **Proper Synchronization**: Uses semaphores and mutexes correctly, no busy waiting
3. ✅ **Deadlock Prevention**: Banker's Algorithm ensures system safety
4. ✅ **Modular Architecture**: Clean separation of concerns
5. ✅ **User-Friendly Interface**: Menu-driven system for easy interaction

### Educational Value:

The simulator effectively demonstrates:
- How schedulers make decisions
- Importance of synchronization in concurrent systems
- Deadlock prevention mechanisms
- Integration of multiple OS components

### Future Enhancements:

Potential improvements for expansion:
- Multi-core CPU scheduling
- I/O operations and device management
- More scheduling algorithms (SJF, FCFS, etc.)
- Real-time scheduling support
- Performance profiling and metrics
- GUI interface for visualization

This project provides a solid foundation for understanding operating system internals and can serve as a stepping stone for more advanced projects such as cloud OS simulators or kernel-level schedulers.

---

## References

1. Silberschatz, A., Galvin, P. B., & Gagne, G. (2018). *Operating System Concepts* (10th ed.). Wiley.
2. Tanenbaum, A. S., & Bos, H. (2014). *Modern Operating Systems* (4th ed.). Pearson.
3. Dijkstra, E. W. (1965). "Cooperating Sequential Processes". *Technical Report EWD-123*.

---

**End of Report**
