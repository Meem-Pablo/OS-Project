# Mini Operating System Simulator

A comprehensive command-line based simulator that integrates Process Scheduling, Producer-Consumer pattern, and Deadlock Prevention using Banker's Algorithm.

## Project Overview

This simulator demonstrates core operating system concepts:
- **Part A**: CPU Scheduling (Priority & Round Robin)
- **Part B**: Producer-Consumer with Synchronization
- **Part C**: Resource Management & Deadlock Prevention

## Features

### Part A: Process Scheduling Module (40%)
- **Priority Scheduling** (Non-preemptive): Higher priority number = higher priority
- **Round Robin Scheduling** (Preemptive): Time quantum = 2 units
- **Dynamic Scheduler Selection**: 
  - ≤ 5 ready processes → Priority Scheduling
  - > 5 ready processes → Round Robin
- **Statistics Display**: Gantt Chart, Waiting Time, Turnaround Time, Averages

### Part B: Producer-Consumer Module (30%)
- **2+ Producer Threads**: Generate processes dynamically
- **1+ Consumer Thread**: Fetches processes from buffer
- **Bounded Buffer**: Size 10 (configurable)
- **Synchronization**: 
  - Semaphores for empty/full buffer slots
  - Mutex for mutual exclusion
  - **No busy waiting** - uses blocking semaphores

### Part C: Resource Management & Deadlock Prevention (30%)
- **Banker's Algorithm**: Simplified implementation
- **Safety Checking**: Before process execution
- **Resource Management**: Max, Allocation, Available matrices
- **Display**: Safe sequence, blocked processes list

## Project Structure

```
Mini-Operating-System-Simulator/
│
├── include/                    # Header files (.h)
│   ├── process.h              # Process data structure definition
│   ├── scheduler.h            # CPU scheduler classes
│   ├── producer_consumer.h     # Producer-Consumer pattern
│   └── banker.h               # Banker's Algorithm
│
├── src/                        # Source files (.cpp)
│   ├── process.cpp             # Process implementation
│   ├── scheduler.cpp           # Scheduler algorithms
│   ├── producer_consumer.cpp   # Producer-Consumer implementation
│   ├── banker.cpp              # Banker's Algorithm implementation
│   └── main.cpp                # Main program and menu
│
├── build/                      # Build output (generated)
│   └── os_simulator           # Executable
│
├── docs/                       # Documentation
│   ├── README.md              # This file
│   ├── REPORT.md              # Project report
│   └── generate_pdf.html      # HTML report for PDF generation
│
├── Makefile                    # Build configuration
└── PROJECT_STRUCTURE.md        # Detailed structure documentation
```

## Prerequisites

### Required Packages

```bash
# Install build tools
sudo apt install build-essential g++ -y

# Install clang (optional, g++ works fine)
sudo apt install clang-20 -y
```

### Compiler Requirements
- C++11 or higher
- pthread support (usually included with g++)

## Building the Project

### Using Makefile (Recommended)

```bash
# Build the project
make

# Clean build artifacts
make clean

# Rebuild from scratch
make rebuild

# Show help
make help
```

The Makefile automatically:
- Compiles all source files from `src/` directory
- Links with header files from `include/` directory
- Places output in `build/` directory

### Running the Simulator

```bash
# After building
./build/os_simulator
```

## Running the Simulator

```bash
./os_simulator
```

## Usage

### Main Menu Options

1. **Start Simulation**
   - Starts producer-consumer threads
   - Producers generate processes dynamically
   - Consumer adds processes to ready queue
   - Press Enter to stop and run scheduler
   - Scheduler automatically selects algorithm based on process count

2. **Add Process Manually**
   - Add a process with custom parameters:
     - Process ID
     - Arrival Time
     - Burst Time
     - Priority
     - Resource Requirements (R1, R2, ...)
   - System checks if resources can be allocated safely

3. **Display System State**
   - Shows all processes and their status
   - Displays buffer state
   - Shows ready queue
   - Displays Banker's Algorithm state (matrices)
   - Shows safe sequence (if exists)
   - Lists blocked processes

4. **Exit**
   - Cleanly exits the simulator

## Example Workflow

1. **Start the simulator**: `./os_simulator`
2. **Add processes manually** (Option 2) or **Start simulation** (Option 1)
3. **View system state** (Option 3) to see processes, buffer, and resource allocation
4. **Run scheduler** automatically when stopping simulation or after adding processes
5. **View results**: Gantt chart, waiting times, turnaround times

## Technical Details

### Process Structure
Each process contains:
- Process ID
- Arrival Time
- CPU Burst Time
- Priority
- Resource Requirement Vector (R1, R2, ...)
- Scheduling statistics (waiting time, turnaround time, completion time)

### Synchronization
- **Semaphores**: `sem_t` for empty/full buffer slots
- **Mutex**: `std::mutex` for critical sections
- **No Busy Waiting**: All waits are blocking

### Resource Management
- **2 Resource Types**: R1 and R2 (configurable)
- **Initial Available**: 10 units each (configurable)
- **Safety Check**: Before every resource allocation

## Limitations

1. **Simplified Banker's Algorithm**: 
   - Fixed number of resource types (currently 2)
   - Simplified safety check for demonstration

2. **Time Quantum**: 
   - Fixed at 2 units for Round Robin
   - Can be modified in `RoundRobinScheduler` constructor

3. **Buffer Size**: 
   - Fixed at 10 processes
   - Can be modified in `MiniOSSimulator` constructor

4. **Process Generation**: 
   - Random generation in producer threads
   - Can be customized in `producerFunction`

## Future Enhancements

- GUI interface
- More scheduling algorithms (SJF, FCFS, etc.)
- Multiple resource types configuration
- Process migration between queues
- Real-time scheduling support
- Performance metrics and logging

## Troubleshooting

### Compilation Errors

**Error: `semaphore.h: No such file or directory`**
- Solution: Ensure you're on Linux. macOS uses `dispatch/semaphore.h` (different API)
- This project is designed for Linux systems

**Error: `undefined reference to pthread`**
- Solution: Add `-pthread` flag to compilation

### Runtime Issues

**Segmentation Fault**
- Ensure all threads are properly joined before exit
- Check buffer bounds

**Deadlock in Producer-Consumer**
- Verify semaphore initialization
- Check mutex locking/unlocking

## Contributing

This is an academic project. For improvements:
1. Maintain modular structure
2. Add comments for complex logic
3. Test with various scenarios
4. Update documentation

## License

Academic/Educational Use

## Author

Mini OS Simulator - Complex Computing Problem (CCP)

---

**Note**: This simulator is designed for educational purposes to demonstrate OS concepts. It is not a real operating system.
