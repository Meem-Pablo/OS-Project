/**
 * ============================================================================
 * scheduler.cpp - CPU Scheduler Module Implementation
 * ============================================================================
 * 
 * Implementation of Priority Scheduling and Round Robin Scheduling algorithms.
 * 
 * ============================================================================
 */

#include "scheduler.h"
#include <algorithm>
#include <iomanip>
#include <sstream>
#include <memory>
using namespace std;

// ============================================================================
// Priority Scheduling Implementation (Non-preemptive)
// ============================================================================

/**
 * Priority Scheduling Algorithm
 * 
 * Algorithm Steps:
 * 1. Sort processes by arrival time
 * 2. At each time unit, add arrived processes to ready queue
 * 3. Sort ready queue by priority (descending)
 * 4. Execute highest priority process completely (non-preemptive)
 * 5. Calculate statistics and generate Gantt chart
 * 
 * @param processes Vector of processes to schedule (modified in-place)
 * @return SchedulingStats containing results
 */
SchedulingStats PriorityScheduler::schedule(vector<Process>& processes) {
    SchedulingStats stats;
    vector<Process> readyQueue;  // Ready queue for processes waiting for CPU
    vector<Process> completed;  // List of completed processes
    
    // Reset all processes to initial state for fresh scheduling run
    for (auto& p : processes) {
        p.reset();
    }
    
    // Sort processes by arrival time to process them in chronological order
    sort(processes.begin(), processes.end(), 
              [](const Process& a, const Process& b) {
                  return a.arrivalTime < b.arrivalTime;
              });
    
    int currentTime = 0;        // Current simulation time
    int processIndex = 0;       // Index of next process to check for arrival
    ostringstream gantt;        // Stream for building Gantt chart string
    
    // Main scheduling loop: continue until all processes are processed
    while (static_cast<size_t>(processIndex) < processes.size() || !readyQueue.empty()) {
        // Add all processes that have arrived at current time to ready queue
        while (static_cast<size_t>(processIndex) < processes.size() &&
               processes[processIndex].arrivalTime <= currentTime) {
            readyQueue.push_back(processes[processIndex]);
            processIndex++;
        }
        
        // If no process is ready, advance time (idle CPU)
        if (readyQueue.empty()) {
            currentTime++;
            continue;
        }
        
        // Sort ready queue by priority (higher priority number = higher priority)
        // This ensures highest priority process is always at front
        sort(readyQueue.begin(), readyQueue.end(),
                  [](const Process& a, const Process& b) {
                      return a.priority > b.priority;  // Descending order
                  });
        
        // Execute highest priority process (non-preemptive: runs to completion)
        Process& current = readyQueue[0];
        
        // Build Gantt chart entry: |P1(0-5)|
        gantt << "|P" << current.processId << "(" << currentTime << "-";
        
        // Calculate waiting time: time spent waiting in ready queue
        current.waitingTime = currentTime - current.arrivalTime;
        
        // Execute process completely (non-preemptive)
        currentTime += current.burstTime;
        
        // Update process statistics
        current.completionTime = currentTime;
        current.turnaroundTime = current.completionTime - current.arrivalTime;
        current.isCompleted = true;
        
        // Complete Gantt chart entry
        gantt << currentTime << ")|";
        
        // Move to completed list and remove from ready queue
        completed.push_back(current);
        readyQueue.erase(readyQueue.begin());
    }
    
    // Calculate average statistics
    double totalWaiting = 0, totalTurnaround = 0;
    for (const auto& p : completed) {
        totalWaiting += p.waitingTime;
        totalTurnaround += p.turnaroundTime;
    }
    
    stats.avgWaitingTime = completed.empty() ? 0 : totalWaiting / completed.size();
    stats.avgTurnaroundTime = completed.empty() ? 0 : totalTurnaround / completed.size();
    stats.ganttChart = gantt.str();
    stats.completedProcesses = completed;
    
    return stats;
}

// ============================================================================
// Round Robin Scheduling Implementation (Preemptive)
// ============================================================================

/**
 * Round Robin Scheduling Algorithm
 * 
 * Algorithm Steps:
 * 1. Sort processes by arrival time
 * 2. At each time unit, add arrived processes to ready queue
 * 3. Execute current process for time quantum (or until completion)
 * 4. If process not completed, preempt and add back to queue
 * 5. Update waiting times for processes in queue
 * 6. Continue until all processes complete
 * 
 * @param processes Vector of processes to schedule (modified in-place)
 * @return SchedulingStats containing results
 */
SchedulingStats RoundRobinScheduler::schedule(vector<Process>& processes) {
    SchedulingStats stats;
    queue<Process*> readyQueue;  // Ready queue (FIFO for Round Robin)
    vector<Process> completed;  // List of completed processes
    
    // Reset all processes to initial state
    for (auto& p : processes) {
        p.reset();
    }
    
    // Sort processes by arrival time
    sort(processes.begin(), processes.end(),
              [](const Process& a, const Process& b) {
                  return a.arrivalTime < b.arrivalTime;
              });
    
    int currentTime = 0;           // Current simulation time
    int processIndex = 0;          // Index of next process to check
    ostringstream gantt;           // Gantt chart builder
    Process* currentProcess = nullptr;  // Currently executing process
    
    // Main scheduling loop
    while (static_cast<size_t>(processIndex) < processes.size() || 
           !readyQueue.empty() || 
           currentProcess != nullptr) {
        
        // Add processes that have arrived at current time
        while (static_cast<size_t>(processIndex) < processes.size() &&
               processes[processIndex].arrivalTime <= currentTime) {
            readyQueue.push(&processes[processIndex]);
            processIndex++;
        }
        
        // If no process currently executing, get one from queue
        if (currentProcess == nullptr && !readyQueue.empty()) {
            currentProcess = readyQueue.front();
            readyQueue.pop();
            
            // Calculate initial waiting time (if process waited before first execution)
            if (currentProcess->waitingTime == 0 && currentProcess->arrivalTime < currentTime) {
                currentProcess->waitingTime = currentTime - currentProcess->arrivalTime;
            }
        }
        
        // If still no process, advance time (idle CPU)
        if (currentProcess == nullptr) {
            currentTime++;
            continue;
        }
        
        // Execute process for time quantum or until completion
        gantt << "|P" << currentProcess->processId << "(" << currentTime << "-";
        
        // Execute for minimum of quantum or remaining time
        int executionTime = min(timeQuantum, currentProcess->remainingTime);
        currentTime += executionTime;
        currentProcess->remainingTime -= executionTime;
        
        gantt << currentTime << ")|";
        
        // Update waiting time for all processes waiting in queue
        // They waited for the duration of this execution
        queue<Process*> tempQueue = readyQueue;
        while (!tempQueue.empty()) {
            Process* p = tempQueue.front();
            tempQueue.pop();
            p->waitingTime += executionTime;
        }
        
        // Check if process completed
        if (currentProcess->remainingTime == 0) {
            // Process completed: update statistics
            currentProcess->completionTime = currentTime;
            currentProcess->turnaroundTime = currentProcess->completionTime - currentProcess->arrivalTime;
            currentProcess->isCompleted = true;
            completed.push_back(*currentProcess);
            currentProcess = nullptr;
        } else {
            // Process not completed: preempt and add back to queue
            readyQueue.push(currentProcess);
            currentProcess = nullptr;
        }
    }
    
    // Calculate average statistics
    double totalWaiting = 0, totalTurnaround = 0;
    for (const auto& p : completed) {
        totalWaiting += p.waitingTime;
        totalTurnaround += p.turnaroundTime;
    }
    
    stats.avgWaitingTime = completed.empty() ? 0 : totalWaiting / completed.size();
    stats.avgTurnaroundTime = completed.empty() ? 0 : totalTurnaround / completed.size();
    stats.ganttChart = gantt.str();
    stats.completedProcesses = completed;
    
    return stats;
}

// ============================================================================
// Scheduler Factory Implementation
// ============================================================================

/**
 * Create Appropriate Scheduler Based on Process Count
 * 
 * Implements the dynamic scheduler selection rule:
 * - ≤ 5 processes: Priority Scheduling (efficient for small workloads)
 * - > 5 processes: Round Robin Scheduling (fair for larger workloads)
 * 
 * @param numProcesses Number of ready processes
 * @return Unique pointer to appropriate scheduler instance
 */
unique_ptr<Scheduler> SchedulerFactory::createScheduler(int numProcesses) {
    if (numProcesses <= 5) {
        // Small workload: Use Priority Scheduling
        // More efficient, fewer context switches
        return unique_ptr<Scheduler>(new PriorityScheduler());
    } else {
        // Large workload: Use Round Robin Scheduling
        // Ensures fairness, prevents starvation
        return unique_ptr<Scheduler>(new RoundRobinScheduler());
    }
}
