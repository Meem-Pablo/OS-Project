/**
 * ============================================================================
 * process.cpp - Process Implementation
 * ============================================================================
 * 
 * Implementation of the Process structure methods.
 * 
 * ============================================================================
 */

#include "process.h"
#include <sstream>
#include <iomanip>
#include <algorithm>
using namespace std;

/**
 * Process Constructor
 * 
 * Initializes a new process with the given parameters and sets all
 * scheduling statistics to zero.
 * 
 * @param id        Unique process identifier
 * @param arrival   Arrival time in the system
 * @param burst     CPU burst time required
 * @param prio      Priority level (higher = higher priority)
 * @param resources Vector of resource requirements [R1, R2, ...]
 */
Process::Process(int id, int arrival, int burst, int prio, 
                 const vector<int>& resources)
    : processId(id),                    // Set process ID
      arrivalTime(arrival),              // Set arrival time
      burstTime(burst),                  // Set burst time
      priority(prio),                    // Set priority
      resourceRequirement(resources),    // Set resource requirements
      waitingTime(0),                    // Initialize waiting time to 0
      turnaroundTime(0),                // Initialize turnaround time to 0
      completionTime(0),                 // Initialize completion time to 0
      remainingTime(burst),              // Initially, remaining = burst
      isCompleted(false),                // Process not completed yet
      isBlocked(false) {                 // Process not blocked initially
    
    // Initialize resource allocation vectors
    // Allocated resources start at 0 (nothing allocated yet)
    allocatedResources.resize(resources.size(), 0);
    
    // Store maximum resource requirements
    maxResources = resources;
}

/**
 * Reset Process State
 * 
 * Resets all scheduling-related statistics to their initial values.
 * This is useful when re-running schedulers on the same process set
 * to get fresh statistics.
 * 
 * Note: Does not reset processId, arrivalTime, burstTime, priority,
 *       or resourceRequirement as these are fundamental process attributes.
 */
void Process::reset() {
    // Reset scheduling statistics
    waitingTime = 0;
    turnaroundTime = 0;
    completionTime = 0;
    remainingTime = burstTime;  // Reset to original burst time
    
    // Reset status flags
    isCompleted = false;
    isBlocked = false;
    
    // Reset allocated resources to zero
    fill(allocatedResources.begin(), allocatedResources.end(), 0);
}

/**
 * Convert Process to String Representation
 * 
 * Creates a human-readable string representation of the process.
 * Format: "P{id} [AT:{arrival} BT:{burst} P:{priority}]"
 * 
 * Example: "P1 [AT:0 BT:5 P:3]" means:
 *   - Process ID: 1
 *   - Arrival Time: 0
 *   - Burst Time: 5
 *   - Priority: 3
 * 
 * @return String representation of the process
 */
string Process::toString() const {
    ostringstream oss;
    oss << "P" << processId 
        << " [AT:" << arrivalTime 
        << " BT:" << burstTime 
        << " P:" << priority << "]";
    return oss.str();
}
