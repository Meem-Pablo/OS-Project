/**
 * ============================================================================
 * producer_consumer.cpp - Producer-Consumer Module Implementation
 * ============================================================================
 * 
 * Implementation of the Producer-Consumer pattern with proper synchronization.
 * 
 * Key Features:
 * - Semaphores for empty/full buffer control (NO BUSY WAITING)
 * - Mutex for critical section protection
 * - Multiple producer threads
 * - Single consumer thread
 * 
 * ============================================================================
 */

#include "producer_consumer.h"
#include <iostream>
#include <random>
#include <chrono>
#include <unistd.h>
using namespace std;

// ============================================================================
// Bounded Buffer Implementation
// ============================================================================

/**
 * Bounded Buffer Constructor
 * 
 * Initializes the buffer with specified size and sets up semaphores.
 * 
 * Semaphore Initialization:
 * - emptySlots: Initialized to maxSize (all slots are empty initially)
 * - fullSlots: Initialized to 0 (no slots are full initially)
 * 
 * @param size Maximum capacity of the buffer
 */
BoundedBuffer::BoundedBuffer(size_t size) : maxSize(size) {
    // Initialize semaphore for empty slots
    // Second parameter (0) means semaphore is shared between threads of process
    // Third parameter (maxSize) is initial value (all slots empty)
    sem_init(&emptySlots, 0, maxSize);
    
    // Initialize semaphore for full slots
    // Initial value is 0 (no slots are full initially)
    sem_init(&fullSlots, 0, 0);
}

/**
 * Bounded Buffer Destructor
 * 
 * Cleans up semaphore resources to prevent memory leaks.
 */
BoundedBuffer::~BoundedBuffer() {
    sem_destroy(&emptySlots);
    sem_destroy(&fullSlots);
}

/**
 * Produce Operation
 * 
 * Adds a process to the buffer. This is the producer operation.
 * 
 * Synchronization Steps (NO BUSY WAITING):
 * 1. sem_wait(&emptySlots): Wait for an empty slot
 *    - If buffer is full, this BLOCKS (thread sleeps)
 *    - NO busy waiting - thread yields CPU
 * 2. Acquire mutex: Enter critical section
 * 3. Add process to buffer
 * 4. Release mutex: Exit critical section
 * 5. sem_post(&fullSlots): Signal that a slot is now full
 * 
 * @param process Process to add to buffer
 * @return true if successful
 */
bool BoundedBuffer::produce(const Process& process) {
    // Step 1: Wait for empty slot (BLOCKS if buffer full - NO BUSY WAITING)
    sem_wait(&emptySlots);
    
    // Step 2-4: Critical section - protect buffer access with mutex
    {
        lock_guard<mutex> lock(mtx);  // Automatically unlocks when scope exits
        buffer.push(process);         // Add process to buffer
    }  // Mutex automatically released here
    
    // Step 5: Signal that a slot is now full (wake up waiting consumer if any)
    sem_post(&fullSlots);
    
    return true;
}

/**
 * Consume Operation
 * 
 * Removes a process from the buffer. This is the consumer operation.
 * 
 * Synchronization Steps (NO BUSY WAITING):
 * 1. sem_wait(&fullSlots): Wait for a full slot
 *    - If buffer is empty, this BLOCKS (thread sleeps)
 *    - NO busy waiting - thread yields CPU
 * 2. Acquire mutex: Enter critical section
 * 3. Remove process from buffer
 * 4. Release mutex: Exit critical section
 * 5. sem_post(&emptySlots): Signal that a slot is now empty
 * 
 * @param process Reference to store the consumed process
 * @return true if successful, false if buffer was empty
 */
bool BoundedBuffer::consume(Process& process) {
    // Step 1: Wait for full slot (BLOCKS if buffer empty - NO BUSY WAITING)
    sem_wait(&fullSlots);
    
    // Step 2-4: Critical section - protect buffer access with mutex
    {
        lock_guard<mutex> lock(mtx);  // Automatically unlocks when scope exits
        
        // Safety check: verify buffer is not empty
        if (buffer.empty()) {
            sem_post(&fullSlots);  // Restore semaphore count
            return false;
        }
        
        // Remove process from buffer
        process = buffer.front();
        buffer.pop();
    }  // Mutex automatically released here
    
    // Step 5: Signal that a slot is now empty (wake up waiting producer if any)
    sem_post(&emptySlots);
    
    return true;
}

/**
 * Get Buffer Size
 * 
 * Thread-safe method to get current number of processes in buffer.
 * 
 * @return Number of processes currently in buffer
 */
size_t BoundedBuffer::size() const {
    lock_guard<mutex> lock(const_cast<mutex&>(mtx));  // Need mutex for thread safety
    return buffer.size();
}

/**
 * Check if Buffer is Empty
 * 
 * Thread-safe check for empty buffer.
 * 
 * @return true if buffer is empty
 */
bool BoundedBuffer::isEmpty() const {
    lock_guard<mutex> lock(const_cast<mutex&>(mtx));
    return buffer.empty();
}

/**
 * Check if Buffer is Full
 * 
 * Thread-safe check for full buffer.
 * 
 * @return true if buffer is at maximum capacity
 */
bool BoundedBuffer::isFull() const {
    lock_guard<mutex> lock(const_cast<mutex&>(mtx));
    return buffer.size() >= maxSize;
}

/**
 * Get All Processes in Buffer
 * 
 * Creates a copy of all processes currently in the buffer.
 * Used for display purposes in the system state.
 * 
 * @return Vector containing all processes in buffer
 */
vector<Process> BoundedBuffer::getAllProcesses() const {
    lock_guard<mutex> lock(const_cast<mutex&>(mtx));
    vector<Process> processes;
    
    // Create a copy of the buffer to iterate over
    queue<Process> tempQueue = buffer;
    
    // Extract all processes
    while (!tempQueue.empty()) {
        processes.push_back(tempQueue.front());
        tempQueue.pop();
    }
    
    return processes;
}

// ============================================================================
// Producer-Consumer Manager Implementation
// ============================================================================

/**
 * Producer-Consumer Manager Constructor
 * 
 * Initializes the manager with a bounded buffer and sets up thread control flags.
 * 
 * @param buf Pointer to the shared bounded buffer
 * @param numProducers Number of producer threads (currently fixed at 2)
 */
ProducerConsumerManager::ProducerConsumerManager(BoundedBuffer* buf, int numProducers)
    : buffer(buf),                    // Store buffer pointer
      running(false),                 // Initially not running
      processIdCounter(1) {           // Start process IDs at 1
}

/**
 * Producer-Consumer Manager Destructor
 * 
 * Ensures clean shutdown by stopping all threads.
 */
ProducerConsumerManager::~ProducerConsumerManager() {
    stop();  // Stop all threads before destruction
}

/**
 * Producer Thread Function
 * 
 * This function runs in each producer thread. It continuously generates
 * processes with random attributes and adds them to the bounded buffer.
 * 
 * Process Generation:
 * - Process ID: Auto-incremented (thread-safe)
 * - Arrival Time: Random (0-5)
 * - Burst Time: Random (1-10)
 * - Priority: Random (1-10)
 * - Resources: Random (0-3 for each resource type)
 * 
 * @param producerId Unique identifier for this producer thread (1, 2, ...)
 */
void ProducerConsumerManager::producerFunction(int producerId) {
    // Initialize random number generators
    random_device rd;  // Non-deterministic random seed
    mt19937 gen(rd()); // Mersenne Twister random number generator
    
    // Define distributions for random process attributes
    uniform_int_distribution<> arrivalDist(0, 5);    // Arrival time: 0-5
    uniform_int_distribution<> burstDist(1, 10);     // Burst time: 1-10
    uniform_int_distribution<> priorityDist(1, 10);  // Priority: 1-10
    uniform_int_distribution<> resourceDist(0, 3);   // Resources: 0-3 per type
    
    int processCount = 0;  // Track number of processes generated
    
    // Main producer loop: continue while running flag is true
    while (running.load()) {
        // Generate random process attributes
        int id = getNextProcessId();  // Thread-safe ID generation
        int arrival = arrivalDist(gen);
        int burst = burstDist(gen);
        int priority = priorityDist(gen);
        vector<int> resources = {resourceDist(gen), resourceDist(gen)};  // 2 resource types
        
        // Create new process
        Process newProcess(id, arrival, burst, priority, resources);
        
        // Add process to buffer (may block if buffer is full)
        if (buffer->produce(newProcess)) {
            cout << "[Producer " << producerId << "] Generated: " 
                      << newProcess.toString() << endl;
            processCount++;
        }
        
        // Sleep for random time to simulate realistic process generation rate
        // Base delay: 500ms + random 0-500ms = 500-1000ms between generations
        this_thread::sleep_for(chrono::milliseconds(500 + arrivalDist(gen) * 100));
    }
    
    // Producer thread finished
    cout << "[Producer " << producerId << "] Stopped. Generated " 
              << processCount << " processes." << endl;
}

/**
 * Consumer Thread Function
 * 
 * This function runs in the consumer thread. It continuously consumes
 * processes from the bounded buffer and adds them to the ready queue
 * for scheduling.
 * 
 * @param readyQueue Reference to the ready queue (shared with main thread)
 * @param queueMutex Mutex protecting the ready queue
 */
void ProducerConsumerManager::consumerFunction(vector<Process>& readyQueue, 
                                                mutex& queueMutex) {
    int consumedCount = 0;  // Track number of processes consumed
    
    // Main consumer loop: continue while running OR buffer has items
    // (allows consuming remaining items after producers stop)
    while (running.load() || !buffer->isEmpty()) {
        // Create temporary process to hold consumed data
        Process process(0, 0, 0, 0);  // Dummy values, will be overwritten
        
        // Consume process from buffer (may block if buffer is empty)
        if (buffer->consume(process)) {
            // Add to ready queue (protected by mutex)
            {
                lock_guard<mutex> lock(queueMutex);  // Protect ready queue
                readyQueue.push_back(process);
            }  // Mutex automatically released
            
            cout << "[Consumer] Consumed: " << process.toString() 
                      << " (Buffer size: " << buffer->size() << ")" << endl;
            consumedCount++;
        }
        
        // Small delay to prevent tight loop and reduce CPU usage
        this_thread::sleep_for(chrono::milliseconds(100));
    }
    
    // Consumer thread finished
    cout << "[Consumer] Stopped. Consumed " << consumedCount << " processes." << endl;
}

/**
 * Start Producer-Consumer Threads
 * 
 * Creates and starts all producer and consumer threads.
 * 
 * @param readyQueue Reference to ready queue for consumer
 * @param queueMutex Mutex protecting the ready queue
 */
void ProducerConsumerManager::start(vector<Process>& readyQueue, 
                                     mutex& queueMutex) {
    // Check if already running
    if (running.load()) {
        return;
    }
    
    // Set running flag to true
    running = true;
    
    // Create and start producer threads (at least 2 as per requirements)
    int numProducers = 2;
    for (int i = 0; i < numProducers; ++i) {
        // Create thread running producerFunction with producer ID (i+1)
        producerThreads.emplace_back(&ProducerConsumerManager::producerFunction, 
                                     this, i + 1);
    }
    
    // Create and start consumer thread
    consumerThread = thread(&ProducerConsumerManager::consumerFunction, 
                                 this, ref(readyQueue), ref(queueMutex));
}

/**
 * Stop Producer-Consumer Threads
 * 
 * Signals all threads to stop and waits for them to finish execution.
 * Ensures clean shutdown without resource leaks.
 */
void ProducerConsumerManager::stop() {
    // Check if already stopped
    if (!running.load()) {
        return;
    }
    
    // Signal threads to stop
    running = false;
    
    // Wait for all producer threads to finish
    for (auto& thread : producerThreads) {
        if (thread.joinable()) {
            thread.join();  // Wait for thread to complete
        }
    }
    producerThreads.clear();  // Clear thread handles
    
    // Wait for consumer thread to finish
    if (consumerThread.joinable()) {
        consumerThread.join();  // Wait for thread to complete
    }
}
