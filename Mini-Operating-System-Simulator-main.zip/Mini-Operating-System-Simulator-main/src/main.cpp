#include <iostream>
#include <vector>
#include <iomanip>
#include <thread>
#include <chrono>
#include <mutex>
#include <limits>
#include "process.h"
#include "scheduler.h"
#include "producer_consumer.h"
#include "banker.h"
using namespace std;

class MiniOSSimulator {
private:
    vector<Process> processes;
    vector<Process> readyQueue;
    mutex queueMutex;
    BoundedBuffer* buffer;
    ProducerConsumerManager* pcManager;
    BankersAlgorithm* banker;
    int numResourceTypes;
    vector<int> availableResources;
    
    void displayMenu();
    void startSimulation();
    void addProcessManually();
    void displaySystemState();
    void displaySchedulingResults(const SchedulingStats& stats);
    void runScheduler();
    
public:
    MiniOSSimulator();
    ~MiniOSSimulator();
    void run();
};

MiniOSSimulator::MiniOSSimulator() {
    // Initialize resource management
    numResourceTypes = 2;
    availableResources = {10, 10};  // 10 units of R1, 10 units of R2
    banker = new BankersAlgorithm(numResourceTypes, availableResources);
    
    // Initialize bounded buffer (size 10)
    buffer = new BoundedBuffer(10);
    pcManager = new ProducerConsumerManager(buffer, 2);
}

MiniOSSimulator::~MiniOSSimulator() {
    if (pcManager) {
        pcManager->stop();
        delete pcManager;
    }
    delete buffer;
    delete banker;
}

void MiniOSSimulator::displayMenu() {
    cout << "\n========================================\n";
    cout << "   Mini OS Simulator - Main Menu\n";
    cout << "========================================\n";
    cout << "1. Start Simulation\n";
    cout << "2. Add Process Manually\n";
    cout << "3. Display System State\n";
    cout << "4. Exit\n";
    cout << "========================================\n";
    cout << "Enter your choice: ";
}

void MiniOSSimulator::addProcessManually() {
    int id, arrival, burst, priority;
    vector<int> resources(numResourceTypes);
    
    // Clear any leftover input from previous operations
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    
    cout << "\n--- Add Process Manually ---\n";
    
    // Get Process ID with validation
    while (true) {
        cout << "Process ID: ";
        if (cin >> id) {
            break;
        } else {
            cout << "Invalid input. Please enter a valid integer.\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
    }
    
    // Get Arrival Time with validation
    while (true) {
        cout << "Arrival Time: ";
        if (cin >> arrival) {
            break;
        } else {
            cout << "Invalid input. Please enter a valid integer.\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
    }
    
    // Get Burst Time with validation
    while (true) {
        cout << "Burst Time: ";
        if (cin >> burst) {
            if (burst > 0) {
                break;
            } else {
                cout << "Burst time must be greater than 0.\n";
            }
        } else {
            cout << "Invalid input. Please enter a valid integer.\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
    }
    
    // Get Priority with validation
    while (true) {
        cout << "Priority (higher number = higher priority): ";
        if (cin >> priority) {
            break;
        } else {
            cout << "Invalid input. Please enter a valid integer.\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
    }
    
    // Get Maximum Resource Requirements (MAX matrix for Banker's Algorithm)
    // This is the MAXIMUM resources the process will EVER need during its lifetime
    // The process can request resources up to this maximum, but not more
    cout << "\nMaximum Resource Requirements (MAX matrix for Banker's Algorithm):\n";
    cout << "Note: This is the MAXIMUM resources the process will ever need.\n";
    cout << "The process can request resources up to this amount during execution.\n";
    for (int i = 0; i < numResourceTypes; ++i) {
        while (true) {
            cout << "  Maximum R" << (i+1) << " needed: ";
            if (cin >> resources[i]) {
                if (resources[i] >= 0) {
                    break;
                } else {
                    cout << "Resource requirement must be non-negative.\n";
                }
            } else {
                cout << "Invalid input. Please enter a valid integer.\n";
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
            }
        }
    }
    
    // Clear any remaining input
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    
    Process newProcess(id, arrival, burst, priority, resources);
    
    // Check if resources can be allocated safely
    banker->addProcess(id, resources);
    if (banker->canAllocate(id, newProcess)) {
        processes.push_back(newProcess);
        cout << "Process P" << id << " added successfully.\n";
    } else {
        cout << "Warning: Process P" << id 
                  << " cannot be allocated resources safely. It will be blocked.\n";
        newProcess.isBlocked = true;
        processes.push_back(newProcess);
    }
}

void MiniOSSimulator::displaySystemState() {
    cout << "\n=== System State ===\n\n";
    
    // Display processes
    cout << "Processes in System:\n";
    cout << left << setw(8) << "PID" 
              << setw(10) << "Arrival" 
              << setw(10) << "Burst" 
              << setw(10) << "Priority"
              << setw(15) << "Status" << "\n";
    cout << string(53, '-') << "\n";
    
    for (const auto& p : processes) {
        cout << setw(8) << ("P" + to_string(p.processId))
                  << setw(10) << p.arrivalTime
                  << setw(10) << p.burstTime
                  << setw(10) << p.priority;
        
        string status = p.isCompleted ? "Completed" : 
                            (p.isBlocked ? "Blocked" : "Ready");
        cout << setw(15) << status << "\n";
    }
    
    // Display buffer state
    cout << "\nBuffer State:\n";
    cout << "  Size: " << buffer->size() << "/" << 10 << "\n";
    vector<Process> bufferProcesses = buffer->getAllProcesses();
    if (!bufferProcesses.empty()) {
        cout << "  Processes in buffer: ";
        for (const auto& p : bufferProcesses) {
            cout << "P" << p.processId << " ";
        }
        cout << "\n";
    }
    
    // Display ready queue
    {
        lock_guard<mutex> lock(queueMutex);
        cout << "\nReady Queue:\n";
        if (readyQueue.empty()) {
            cout << "  (Empty)\n";
        } else {
            cout << "  Processes: ";
            for (const auto& p : readyQueue) {
                cout << "P" << p.processId << " ";
            }
            cout << "\n";
        }
    }
    
    // Display Banker's Algorithm state
    banker->displayState();
    
    // Display safe sequence
    vector<int> safeSeq = banker->getSafeSequence();
    if (!safeSeq.empty()) {
        cout << "\nSafe Sequence: ";
        for (size_t i = 0; i < safeSeq.size(); ++i) {
            cout << "P" << safeSeq[i];
            if (i < safeSeq.size() - 1) cout << " -> ";
        }
        cout << "\n";
    } else {
        cout << "\nNo safe sequence found (system may be in unsafe state).\n";
    }
    
    // Display blocked processes
    vector<int> blocked = banker->getBlockedProcesses(processes);
    if (!blocked.empty()) {
        cout << "\nBlocked Processes: ";
        for (int pid : blocked) {
            cout << "P" << pid << " ";
        }
        cout << "\n";
    }
}

void MiniOSSimulator::displaySchedulingResults(const SchedulingStats& stats) {
    cout << "\n=== Scheduling Results ===\n";
    if (stats.completedProcesses.empty()) {
        cout << "Algorithm: N/A\n\n";
    } else {
        cout << "Algorithm: " 
                  << (stats.completedProcesses.size() <= 5 ? "Priority Scheduling" : "Round Robin") 
                  << "\n\n";
    }
    
    // Gantt Chart
    cout << "Gantt Chart:\n";
    cout << stats.ganttChart << "\n\n";
    
    // Process details
    cout << left << setw(8) << "Process"
              << setw(12) << "Arrival"
              << setw(12) << "Burst"
              << setw(12) << "Waiting"
              << setw(12) << "Turnaround"
              << setw(12) << "Completion" << "\n";
    cout << string(68, '-') << "\n";
    
    for (const auto& p : stats.completedProcesses) {
        cout << setw(8) << ("P" + to_string(p.processId))
                  << setw(12) << p.arrivalTime
                  << setw(12) << p.burstTime
                  << setw(12) << p.waitingTime
                  << setw(12) << p.turnaroundTime
                  << setw(12) << p.completionTime << "\n";
    }
    
    // Averages
    cout << "\nAverage Waiting Time: " << fixed << setprecision(2) 
              << stats.avgWaitingTime << "\n";
    cout << "Average Turnaround Time: " << fixed << setprecision(2) 
              << stats.avgTurnaroundTime << "\n";
}

void MiniOSSimulator::runScheduler() {
    // Collect ready processes (not blocked, not completed)
    vector<Process> readyProcesses;
    {
        lock_guard<mutex> lock(queueMutex);
        readyProcesses = readyQueue;
        readyQueue.clear();  // Clear ready queue after copying
    }
    
    // CRITICAL FIX: Prioritize manually added processes over auto-generated ones
    // First, add all manually added processes that are ready
    for (const auto& p : processes) {
        if (!p.isCompleted && !p.isBlocked) {
            bool alreadyInQueue = false;
            // Check if this process ID exists in ready queue (from producer-consumer)
            for (const auto& rp : readyProcesses) {
                if (rp.processId == p.processId) {
                    // Process ID conflict: manually added process takes priority
                    // Remove the auto-generated one, keep the manually added one
                    alreadyInQueue = true;
                    break;
                }
            }
            if (!alreadyInQueue) {
                readyProcesses.push_back(p);
            }
        }
    }
    
    // Now process ready queue processes, but skip if ID already exists (manually added takes priority)
    vector<Process> newProcessesFromQueue;
    for (const auto& rp : readyProcesses) {
        bool isManuallyAdded = false;
        // Check if this process ID already exists in main processes list (manually added)
        for (const auto& existing : processes) {
            if (existing.processId == rp.processId) {
                isManuallyAdded = true;
                break;
            }
        }
        
        // Only add if it's a new process (not manually added)
        if (!isManuallyAdded) {
            newProcessesFromQueue.push_back(rp);
        }
    }
    
    // Replace readyProcesses with manually added ones + new ones from queue
    readyProcesses.clear();
    
    // First add manually added processes
    for (const auto& p : processes) {
        if (!p.isCompleted && !p.isBlocked) {
            readyProcesses.push_back(p);
        }
    }
    
    // Then add new processes from queue (that don't conflict)
    for (const auto& np : newProcessesFromQueue) {
        readyProcesses.push_back(np);
    }
    
    // Register new processes with Banker's Algorithm and check resource allocation
    vector<Process> safeProcesses;
    for (auto& p : readyProcesses) {
        // Check if process is already in main process list
        bool found = false;
        Process* existingProcess = nullptr;
        for (auto& existing : processes) {
            if (existing.processId == p.processId) {
                found = true;
                existingProcess = &existing;
                break;
            }
        }
        
        // If process exists (manually added), use that one instead of readyQueue version
        if (found && existingProcess != nullptr) {
            // Use the manually added process, not the one from readyQueue
            p = *existingProcess;
        } else {
            // Register new process with banker
            banker->addProcess(p.processId, p.resourceRequirement);  // Sets MAX[processId]
            processes.push_back(p);
        }
        
        // Check if resources can be allocated safely
        // For simplicity, we check if allocating the full MAX requirement is safe
        // In a real system, processes might request less than MAX incrementally
        if (banker->canAllocate(p.processId, p)) {
            // Try to request the maximum resources (full allocation of MAX)
            // In a real system, this could be done incrementally
            if (banker->requestResources(p.processId, p.resourceRequirement)) {
                safeProcesses.push_back(p);
            } else {
                // Update the process in the main list
                for (auto& proc : processes) {
                    if (proc.processId == p.processId) {
                        proc.isBlocked = true;
                        break;
                    }
                }
                cout << "Process P" << p.processId 
                          << " blocked: cannot allocate maximum resources safely.\n";
            }
        } else {
            // Update the process in the main list
            for (auto& proc : processes) {
                if (proc.processId == p.processId) {
                    proc.isBlocked = true;
                    break;
                }
            }
            cout << "Process P" << p.processId 
                      << " blocked: unsafe resource allocation (would exceed system safety).\n";
        }
    }
    
    if (safeProcesses.empty()) {
        cout << "\nNo safe processes to schedule (all blocked or no processes).\n";
        return;
    }
    
    // Select scheduler based on number of processes
    auto scheduler = SchedulerFactory::createScheduler(safeProcesses.size());
    cout << "\nSelected Scheduler: " << scheduler->getName() << "\n";
    cout << "Number of ready processes: " << safeProcesses.size() << "\n";
    
    // Run scheduler
    SchedulingStats stats = scheduler->schedule(safeProcesses);
    
    // Update processes with results and release resources
    for (const auto& completed : stats.completedProcesses) {
        for (auto& p : processes) {
            if (p.processId == completed.processId) {
                p = completed;
                // Release resources when process completes
                banker->releaseResources(p.processId);
                break;
            }
        }
    }
    
    // Display results
    displaySchedulingResults(stats);
}

void MiniOSSimulator::startSimulation() {
    cout << "\n=== Starting Simulation ===\n";
    cout << "Starting producer-consumer threads...\n";
    
    // Start producer-consumer
    pcManager->start(readyQueue, queueMutex);
    
    cout << "Simulation running. Press Enter to stop and run scheduler...\n";
    cin.ignore();
    cin.get();
    
    // Stop producer-consumer
    cout << "Stopping producer-consumer...\n";
    pcManager->stop();
    
    // Wait a bit for threads to finish
    this_thread::sleep_for(chrono::milliseconds(500));
    
    // Run scheduler
    runScheduler();
}

void MiniOSSimulator::run() {
    int choice;
    
    while (true) {
        displayMenu();
        
        // Clear input buffer and validate input
        cin.clear();
        if (!(cin >> choice)) {
            cout << "Invalid input. Please enter a number (1-4).\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            continue;
        }
        
        // Clear any remaining input (like newline)
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        
        switch (choice) {
            case 1:
                startSimulation();
                break;
            case 2:
                addProcessManually();
                break;
            case 3:
                displaySystemState();
                break;
            case 4:
                cout << "Exiting...\n";
                return;
            default:
                cout << "Invalid choice. Please enter a number between 1 and 4.\n";
        }
    }
}

int main() {
    cout << "Mini Operating System Simulator\n";
    cout << "Complex Computing Problem (CCP)\n";
    cout << "================================\n";
    
    MiniOSSimulator simulator;
    simulator.run();
    
    return 0;
}
