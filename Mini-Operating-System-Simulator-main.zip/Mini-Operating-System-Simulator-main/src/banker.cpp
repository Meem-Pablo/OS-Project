#include "banker.h"
#include <algorithm>
#include <iostream>
#include <iomanip>
using namespace std;

BankersAlgorithm::BankersAlgorithm(int numResources, const vector<int>& availableResources)
    : numResourceTypes(numResources), available(availableResources) {
    // Initialize matrices
    max.clear();
    allocation.clear();
    need.clear();
}

void BankersAlgorithm::addProcess(int processId, const vector<int>& maxResources) {
    // Ensure we have enough space
    while (max.size() <= static_cast<size_t>(processId)) {
        max.push_back(vector<int>(numResourceTypes, 0));
        allocation.push_back(vector<int>(numResourceTypes, 0));
        need.push_back(vector<int>(numResourceTypes, 0));
    }
    
    max[processId] = maxResources;
    need[processId] = maxResources;  // Initially, need = max (nothing allocated)
}

bool BankersAlgorithm::canAllocate(int processId, const Process& process) {
    // Check if process needs more resources than available
    for (size_t i = 0; i < process.resourceRequirement.size() && i < static_cast<size_t>(numResourceTypes); ++i) {
        if (process.resourceRequirement[i] > available[i]) {
            return false;
        }
    }
    
    // Temporarily allocate and check safety
    vector<int> tempAvailable = available;
    vector<int> tempAllocation = allocation[processId];
    vector<int> tempNeed = need[processId];
    
    // Simulate allocation
    for (size_t i = 0; i < process.resourceRequirement.size() && i < static_cast<size_t>(numResourceTypes); ++i) {
        if (process.resourceRequirement[i] > tempNeed[i]) {
            // Request exceeds need
            return false;
        }
        tempAvailable[i] -= process.resourceRequirement[i];
        tempAllocation[i] += process.resourceRequirement[i];
        tempNeed[i] -= process.resourceRequirement[i];
    }
    
    // Check if this allocation leads to safe state using safety algorithm
    vector<int> work = tempAvailable;
    vector<bool> finish(max.size(), false);
    vector<int> safeSequence;
    
    // Update need for the process we're checking
    vector<vector<int>> tempNeedMatrix = need;
    tempNeedMatrix[processId] = tempNeed;
    vector<vector<int>> tempAllocationMatrix = allocation;
    tempAllocationMatrix[processId] = tempAllocation;
    
    bool found = true;
    while (found) {
        found = false;
        for (size_t i = 0; i < max.size(); ++i) {
            if (!finish[i]) {
                bool canFinish = true;
                for (int j = 0; j < numResourceTypes; ++j) {
                    if (tempNeedMatrix[i][j] > work[j]) {
                        canFinish = false;
                        break;
                    }
                }
                
                if (canFinish) {
                    // Process can finish
                    for (int j = 0; j < numResourceTypes; ++j) {
                        work[j] += tempAllocationMatrix[i][j];
                    }
                    finish[i] = true;
                    safeSequence.push_back(i);
                    found = true;
                }
            }
        }
    }
    
    // Check if all processes finished (safe state)
    bool allFinished = true;
    for (bool f : finish) {
        if (!f) {
            allFinished = false;
            break;
        }
    }
    
    return allFinished;
}

bool BankersAlgorithm::requestResources(int processId, const vector<int>& request) {
    // Validate request
    if (processId >= static_cast<int>(max.size())) {
        return false;
    }
    
    // Check if request exceeds need
    for (int i = 0; i < numResourceTypes; ++i) {
        if (request[i] > need[processId][i]) {
            return false;
        }
    }
    
    // Check if request exceeds available
    for (int i = 0; i < numResourceTypes; ++i) {
        if (request[i] > available[i]) {
            return false;
        }
    }
    
    // Temporarily allocate
    for (int i = 0; i < numResourceTypes; ++i) {
        available[i] -= request[i];
        allocation[processId][i] += request[i];
        need[processId][i] -= request[i];
    }
    
    // Check safety
    vector<int> safeSeq = safetyAlgorithm();
    
    if (safeSeq.empty()) {
        // Unsafe state, rollback
        for (int i = 0; i < numResourceTypes; ++i) {
            available[i] += request[i];
            allocation[processId][i] -= request[i];
            need[processId][i] += request[i];
        }
        return false;
    }
    
    return true;
}

void BankersAlgorithm::releaseResources(int processId) {
    if (processId >= static_cast<int>(allocation.size())) {
        return;
    }
    
    // Release all allocated resources
    for (int i = 0; i < numResourceTypes; ++i) {
        available[i] += allocation[processId][i];
        allocation[processId][i] = 0;
        need[processId][i] = max[processId][i];
    }
}

vector<int> BankersAlgorithm::safetyAlgorithm() {
    vector<int> work = available;
    vector<bool> finish(max.size(), false);
    vector<int> safeSequence;
    
    bool found = true;
    while (found) {
        found = false;
        for (size_t i = 0; i < max.size(); ++i) {
            if (!finish[i]) {
                bool canFinish = true;
                for (int j = 0; j < numResourceTypes; ++j) {
                    if (need[i][j] > work[j]) {
                        canFinish = false;
                        break;
                    }
                }
                
                if (canFinish) {
                    // Process can finish
                    for (int j = 0; j < numResourceTypes; ++j) {
                        work[j] += allocation[i][j];
                    }
                    finish[i] = true;
                    safeSequence.push_back(i);
                    found = true;
                }
            }
        }
    }
    
    // Check if all processes finished
    bool allFinished = true;
    for (bool f : finish) {
        if (!f) {
            allFinished = false;
            break;
        }
    }
    
    return allFinished ? safeSequence : vector<int>();
}

vector<int> BankersAlgorithm::getSafeSequence() {
    return safetyAlgorithm();
}

vector<int> BankersAlgorithm::getBlockedProcesses(const vector<Process>& processes) {
    vector<int> blocked;
    
    for (const auto& process : processes) {
        if (!process.isCompleted && !canAllocate(process.processId, process)) {
            blocked.push_back(process.processId);
        }
    }
    
    return blocked;
}

void BankersAlgorithm::displayState() const {
    cout << "\n=== Banker's Algorithm State ===\n";
    cout << "Available Resources: ";
    for (int i = 0; i < numResourceTypes; ++i) {
        cout << "R" << (i+1) << ":" << available[i] << " ";
    }
    cout << "\n";
    cout << "Note: Alloc shows currently allocated resources. ";
    cout << "Completed processes have released their resources (Alloc = 0).\n";
    cout << "Blocked processes never received resources (Alloc = 0).\n\n";
    
    if (max.empty()) {
        cout << "No processes in system.\n";
        return;
    }
    
    cout << left << setw(8) << "Process";
    for (int i = 0; i < numResourceTypes; ++i) {
        cout << setw(12) << ("Max R" + to_string(i+1));
    }
    for (int i = 0; i < numResourceTypes; ++i) {
        cout << setw(12) << ("Alloc R" + to_string(i+1));
    }
    for (int i = 0; i < numResourceTypes; ++i) {
        cout << setw(12) << ("Need R" + to_string(i+1));
    }
    cout << "\n";
    
    for (size_t i = 0; i < max.size(); ++i) {
        cout << setw(8) << ("P" + to_string(i));
        for (int j = 0; j < numResourceTypes; ++j) {
            cout << setw(12) << max[i][j];
        }
        for (int j = 0; j < numResourceTypes; ++j) {
            cout << setw(12) << allocation[i][j];
        }
        for (int j = 0; j < numResourceTypes; ++j) {
            cout << setw(12) << need[i][j];
        }
        cout << "\n";
    }
}
